$('.answer__btn').on('click', function() {
    $(this).next('.answer__text').slideToggle();
  });